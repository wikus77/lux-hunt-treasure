
import React from 'react';
// GeoJSON component removed as requested

const ItalyRegions: React.FC = () => {
  // This component is now empty as GeoJSON functionality has been removed
  return null;
};

export default ItalyRegions;
