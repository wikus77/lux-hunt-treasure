// © 2025 M1SSION™ NIYVORA KFT– Joseph MULÉ
// FCM Push Registration & Token Management

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getMessaging, getToken, onMessage, isSupported } from 'firebase/messaging';
import { supabase } from '@/integrations/supabase/client';
import type { MessagePayload } from 'firebase/messaging';

// Firebase Configuration - must include messagingSenderId
const firebaseConfig = {
  apiKey: "AIzaSyDt7BJ9kV8Jm9aH3GbS6kL4fP2eR9xW7qZ",
  authDomain: "lux-hunt-treasure.firebaseapp.com",
  projectId: "lux-hunt-treasure",
  storageBucket: "lux-hunt-treasure.appspot.com",
  messagingSenderId: "987654321098",
  appId: "1:987654321098:web:1a2b3c4d5e6f7g8h9i0j1k2l"
};

// VAPID Key from Firebase config
const VAPID_KEY = "BJMuwT6jgq_wAQIccbQKoVOeUkc4dB64CNtSicE8zegs12sHZs0Jz0itIEv2USImnhstQtw219nYydIDKr91n2o";

// Browser detection
const getBrowserInfo = () => {
  const userAgent = navigator.userAgent;
  const isIOS = /iPad|iPhone|iPod/.test(userAgent);
  const isSafari = /^((?!chrome|android).)*safari/i.test(userAgent);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
  
  return { isIOS, isSafari, isStandalone };
};

// Initialize Firebase app once
let app: any = null;
let messaging: any = null;

const initializeFirebase = async () => {
  try {
    // Initialize app if not already done
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    
    // Check messaging support first
    const supported = await isSupported();
    if (!supported) {
      console.warn('❌ FCM-REGISTER: Firebase messaging not supported in this browser');
      return false;
    }
    
    // Initialize messaging
    messaging = getMessaging(app);
    console.log('✅ FCM-REGISTER: Firebase messaging initialized');
    return true;
  } catch (error) {
    console.error('❌ FCM-REGISTER: Firebase initialization failed:', error);
    return false;
  }
};

// Service Worker registration with proper scope validation
export const registerServiceWorker = async (): Promise<ServiceWorkerRegistration | null> => {
  try {
    if (!('serviceWorker' in navigator)) {
      console.warn('❌ FCM-REGISTER: Service Workers not supported');
      return null;
    }

    // Register or get existing FCM service worker with explicit scope
    const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js', {
      scope: '/'
    });
    
    console.log('✅ FCM-REGISTER: Service Worker registered with scope:', registration.scope);
    
    // Wait for service worker to be ready
    if (registration.installing) {
      await new Promise(resolve => {
        registration.installing!.addEventListener('statechange', function() {
          if (this.state === 'activated') resolve(true);
        });
      });
    }
    
    // Ensure service worker is active
    if (!registration.active) {
      await new Promise(resolve => {
        const checkActive = () => {
          if (registration.active) {
            resolve(true);
          } else {
            setTimeout(checkActive, 100);
          }
        };
        checkActive();
      });
    }
    
    console.log('✅ FCM-REGISTER: Service Worker is active and ready');
    return registration;
    
  } catch (error) {
    console.error('❌ FCM-REGISTER: Service Worker registration failed:', error);
    return null;
  }
};

// Request notification permissions
export const requestNotificationPermission = async (): Promise<NotificationPermission> => {
  try {
    if (!('Notification' in window)) {
      console.warn('❌ FCM-REGISTER: Notifications not supported');
      return 'denied';
    }

    // Check current permission
    let permission = Notification.permission;
    
    // Request permission if not granted
    if (permission === 'default') {
      permission = await Notification.requestPermission();
    }
    
    console.log(`📋 FCM-REGISTER: Permission status: ${permission}`);
    return permission;
  } catch (error) {
    console.error('❌ FCM-REGISTER: Permission request failed:', error);
    return 'denied';
  }
};

// Generate FCM token
export const generateFCMToken = async (serviceWorkerRegistration?: ServiceWorkerRegistration): Promise<string | null> => {
  try {
    if (!messaging) {
      console.error('❌ FCM-REGISTER: Firebase messaging not initialized');
      return null;
    }

    if (!VAPID_KEY) {
      console.error('❌ FCM-REGISTER: VAPID key not configured');
      return null;
    }

    console.log('🔄 FCM-REGISTER: Generating token with ENV VAPID key...');
    console.log('🔍 FCM-REGISTER: VAPID source: ENV variable');
    console.log('🔍 FCM-REGISTER: VAPID format: ...', VAPID_KEY.slice(-6));
    
    // Wait for service worker to be ready
    if (serviceWorkerRegistration) {
      await navigator.serviceWorker.ready;
    }
    
    const tokenOptions: any = { vapidKey: VAPID_KEY };
    if (serviceWorkerRegistration) {
      tokenOptions.serviceWorkerRegistration = serviceWorkerRegistration;
      console.log('🔍 FCM-REGISTER: Using SW registration with scope:', serviceWorkerRegistration.scope);
    }
    
    const token = await getToken(messaging, tokenOptions);
    
    if (token) {
      console.log('✅ FCM-REGISTER: Token generated successfully', token.substring(0, 20) + '...');
      console.log('📊 FCM-TOKEN-GENERATED: Token masked for security');
      return token;
    } else {
      console.warn('⚠️ FCM-REGISTER: No registration token available');
      return null;
    }
  } catch (error) {
    console.error('❌ FCM-REGISTER: Token generation failed:', error);
    
    // Log specific error types for better diagnostics
    if (error instanceof Error) {
      console.error('❌ FCM-REGISTER: Error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
    }
    return null;
  }
};

// Save token to Supabase
export const saveTokenToDatabase = async (token: string): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    const tokenData = {
      token,
      platform: 'web' as const,
      user_id: user?.id || null,
    };

    console.log('💾 FCM-REGISTER: Saving token to database...', { 
      hasUser: !!user, 
      tokenPrefix: token.substring(0, 20) + '...' 
    });

    const { error } = await supabase
      .from('push_tokens')
      .upsert(tokenData, { 
        onConflict: 'token',
        ignoreDuplicates: false 
      });

    if (error) {
      console.error('❌ FCM-REGISTER: Database save failed:', error);
      return false;
    }

    console.log('✅ FCM-REGISTER: Token saved to database successfully');
    return true;
  } catch (error) {
    console.error('❌ FCM-REGISTER: Database operation failed:', error);
    return false;
  }
};

// Setup foreground message listener
export const setupForegroundListener = (
  onMessageReceived?: (payload: MessagePayload) => void
) => {
  try {
    if (!messaging) {
      console.error('❌ FCM-REGISTER: Firebase messaging not initialized for foreground listener');
      return null;
    }

    const unsubscribe = onMessage(messaging, (payload) => {
      console.log('📨 FCM-REGISTER: Foreground message received:', payload);
      
      // Default toast notification
      if (payload.notification) {
        // You can integrate with your toast system here
        console.log(`🔔 Notification: ${payload.notification.title} - ${payload.notification.body}`);
      }
      
      // Call custom handler if provided
      if (onMessageReceived) {
        onMessageReceived(payload);
      }
    });

    console.log('✅ FCM-REGISTER: Foreground listener setup');
    return unsubscribe;
  } catch (error) {
    console.error('❌ FCM-REGISTER: Foreground listener setup failed:', error);
    return null;
  }
};

// Main registration function
export const registerPush = async (
  onMessageReceived?: (payload: MessagePayload) => void
): Promise<{
  success: boolean;
  token?: string;
  error?: string;
}> => {
  try {
    console.log('🚀 FCM-REGISTER: Starting push registration process...');

    // Step 0: Check browser compatibility first
    const browserInfo = getBrowserInfo();
    console.log('🔍 FCM-REGISTER: Browser info:', browserInfo);
    
    // Special handling for iOS Safari
    if (browserInfo.isIOS && browserInfo.isSafari && !browserInfo.isStandalone) {
      return {
        success: false,
        error: 'PWA_INSTALL_REQUIRED: Per iOS Safari, i Web Push richiedono l\'app installata nella Home. Installa la PWA e riapri per generare il token.'
      };
    }

    // Step 1: Initialize Firebase
    const firebaseInitialized = await initializeFirebase();
    if (!firebaseInitialized) {
      return {
        success: false,
        error: 'Firebase messaging not supported or initialization failed'
      };
    }

    // Step 2: Validate VAPID key
    if (!VAPID_KEY) {
      return {
        success: false,
        error: 'Missing VAPID key - Firebase configuration required'
      };
    }

    // Step 3: Validate Firebase config
    if (!firebaseConfig.messagingSenderId) {
      return {
        success: false,
        error: 'Missing messagingSenderId in Firebase configuration'
      };
    }

    // Step 4: Register Service Worker with explicit registration return
    const swRegistration = await registerServiceWorker();
    if (!swRegistration) {
      return { 
        success: false, 
        error: 'Service Worker registration failed' 
      };
    }

    // Step 5: Request Permission
    const permission = await requestNotificationPermission();
    if (permission !== 'granted') {
      return { 
        success: false, 
        error: `Notification permission ${permission}` 
      };
    }

    // Step 6: Generate Token with explicit SW registration
    const token = await generateFCMToken(swRegistration);
    if (!token) {
      return { 
        success: false, 
        error: 'Failed to generate FCM token - check VAPID key configuration' 
      };
    }

    // Step 7: Save to Database
    const saved = await saveTokenToDatabase(token);
    if (!saved) {
      return { 
        success: false, 
        error: 'Failed to save token to database' 
      };
    }

    // Step 8: Setup Foreground Listener
    setupForegroundListener(onMessageReceived);

    console.log('🎉 FCM-REGISTER: Push registration completed successfully!');
    return { 
      success: true, 
      token 
    };

  } catch (error) {
    console.error('❌ FCM-REGISTER: Registration process failed:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    };
  }
};

// Check if FCM is supported
export const isFCMSupported = (): boolean => {
  return typeof window !== 'undefined' && 
         'serviceWorker' in navigator && 
         'Notification' in window;
};

// Export browser detection for diagnostics
export const getBrowserDetails = () => getBrowserInfo();

// Export Firebase config validation
export const validateFirebaseConfig = () => {
  return {
    hasMessagingSenderId: !!firebaseConfig.messagingSenderId,
    hasVapidKey: !!VAPID_KEY,
    vapidSource: VAPID_KEY ? 'ENV' : 'MISSING',
    vapidFormat: VAPID_KEY ? VAPID_KEY.slice(-6) : 'N/A'
  };
};

// Get current permission status
export const getPermissionStatus = (): NotificationPermission => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
};

// Check if user has saved tokens
export const getUserTokens = async (): Promise<number> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return 0;

    const { count, error } = await supabase
      .from('push_tokens')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    if (error) {
      console.error('❌ FCM-REGISTER: Failed to get user tokens:', error);
      return 0;
    }

    return count || 0;
  } catch (error) {
    console.error('❌ FCM-REGISTER: Failed to check user tokens:', error);
    return 0;
  }
};