
import React from 'react';
import NewMapPage from './NewMapPage';

const Map = () => {
  return <NewMapPage />;
};

export default Map;
