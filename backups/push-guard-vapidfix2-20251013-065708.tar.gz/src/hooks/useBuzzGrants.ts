// © 2025 Joseph MULÉ – M1SSION™

import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface BuzzGrant {
  id: string;
  source: string;
  remaining: number;
  created_at: string;
}

export const useBuzzGrants = () => {
  const [grants, setGrants] = useState<BuzzGrant[]>([]);
  const [totalRemaining, setTotalRemaining] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dailyUsed, setDailyUsed] = useState(false); // © 2025 M1SSION™ NIYVORA KFT – Joseph MULÉ

  const fetchGrants = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // © 2025 M1SSION™ NIYVORA KFT – Joseph MULÉ - Check if user has already consumed daily free BUZZ today
      const today = new Date().toISOString().split('T')[0];
      
      // Check user_buzz_counter for today's free BUZZ usage
      const { data: todayBuzzUsage, error: buzzError } = await supabase
        .from('user_buzz_counter')
        .select('*')
        .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
        .eq('date', today)
        .single();

      // If any BUZZ was used today, mark daily as used
      if (todayBuzzUsage && todayBuzzUsage.buzz_count > 0) {
        setDailyUsed(true);
      } else {
        setDailyUsed(false);
      }

      const { data, error } = await supabase
        .from('buzz_grants')
        .select('*')
        .gt('remaining', 0)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setGrants(data || []);
      const total = (data || []).reduce((sum, grant) => sum + grant.remaining, 0);
      setTotalRemaining(total);
    } catch (err) {
      console.error('Error fetching buzz grants:', err);
      setError(err instanceof Error ? err.message : 'Unknown error');
      setGrants([]);
      setTotalRemaining(0);
    } finally {
      setIsLoading(false);
    }
  };

  const consumeFreeBuzz = async (): Promise<boolean> => {
    // © 2025 M1SSION™ NIYVORA KFT – Joseph MULÉ - Check daily limit first
    if (dailyUsed) {
      console.log('Daily free BUZZ already used');
      return false;
    }
    
    if (totalRemaining <= 0) return false;

    try {
      // Check one more time if already used today via database
      const today = new Date().toISOString().split('T')[0];
      const userId = (await supabase.auth.getUser()).data.user?.id;
      
      if (!userId) {
        console.error('❌ No user ID found');
        return false;
      }
      
      const { data: todayCheck } = await supabase
        .from('user_buzz_counter')
        .select('buzz_count')
        .eq('user_id', userId)
        .eq('date', today)
        .single();

      if (todayCheck && todayCheck.buzz_count > 0) {
        console.log('❌ Daily BUZZ already used - database check');
        setDailyUsed(true);
        return false;
      }

      // Find the first grant with remaining buzz
      const grantToUse = grants.find(g => g.remaining > 0);
      if (!grantToUse) return false;

      console.log('🎁 CONSUMING FREE BUZZ GRANT:', grantToUse.id);

      const { error } = await supabase
        .from('buzz_grants')
        .update({ 
          remaining: grantToUse.remaining - 1,
          updated_at: new Date().toISOString()
        })
        .eq('id', grantToUse.id);

      if (error) throw error;

      // 🔥 CRITICAL FIX: SAVE CLUE TO DATABASE IMMEDIATELY
      const uniqueClue = `Cerca dove l'innovazione italiana splende (${new Date().toLocaleTimeString()}) - FREE BUZZ ${Date.now()}`;
      
      console.log('💾 SAVING FREE BUZZ CLUE TO DATABASE:', uniqueClue);
      
      const { error: clueError } = await supabase
        .from('user_clues')
        .insert({
          user_id: userId,
          clue_id: `free_buzz_${Date.now()}`,
          title_it: "🎁 Indizio BUZZ Gratuito",
          description_it: uniqueClue,
          clue_type: "buzz",
          buzz_cost: 0,
          week_number: Math.ceil(Date.now() / (1000 * 60 * 60 * 24 * 7))
        });

      if (clueError) {
        console.error('❌ Error saving free buzz clue:', clueError);
      } else {
        console.log('✅ FREE BUZZ CLUE SAVED TO DATABASE');
      }

      // SAVE NOTIFICATION TOO
      const { error: notifError } = await supabase
        .from('user_notifications')
        .insert({
          user_id: userId,
          type: 'buzz',
          title: '🎁 Nuovo Indizio BUZZ Gratuito!',
          message: uniqueClue,
          is_read: false,
          metadata: { free: true, source: 'buzz_grant' }
        });

      if (notifError) {
        console.error('❌ Error saving free buzz notification:', notifError);
      } else {
        console.log('✅ FREE BUZZ NOTIFICATION SAVED');
      }

      // 🔥 TRIGGER REALTIME UPDATE by also updating user_mission_status
      const { error: statusUpdateError } = await supabase
        .from('user_mission_status')
        .upsert({
          user_id: userId,
          clues_found: 1,
          mission_progress_percent: Math.round((1 / 200) * 100),
          updated_at: new Date().toISOString()
        });

      if (statusUpdateError) {
        console.error('❌ Error triggering mission status update:', statusUpdateError);
      } else {
        console.log('✅ MISSION STATUS UPDATE TRIGGERED');
      }

      // Mark daily usage immediately
      setDailyUsed(true);
      
      // Refresh grants after consumption
      await fetchGrants();
      return true;
    } catch (err) {
      console.error('Error consuming free buzz:', err);
      return false;
    }
  };

  useEffect(() => {
    fetchGrants();
  }, []);

  return {
    grants,
    totalRemaining,
    isLoading,
    error,
    fetchGrants,
    consumeFreeBuzz,
    hasFreeBuzz: totalRemaining > 0 && !dailyUsed, // © 2025 M1SSION™ NIYVORA KFT – Joseph MULÉ
    dailyUsed
  };
};