export default function Admin() {
  return (
    <div style={{
      padding: '4rem',
      fontSize: '24px',
      color: 'lime',
      background: 'black',
      textAlign: 'center',
    }}>
      ✅ TEST OK - PAGINA /admin FUNZIONANTE
    </div>
  );
}
