// © 2025 M1SSION™ – NIYVORA KFT – Joseph MULÉ
// M1SSION™ Firebase Notification Debug Page

import React from 'react';
import { FCMDebugPanel } from '@/components/debug/FCMDebugPanel';

export default function FirebaseNotificationDebug() {
  return <FCMDebugPanel />;
}